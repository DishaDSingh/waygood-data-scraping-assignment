
## 1. Missing Field

One field that was unavailable for some courses was the application fee.

Before marking it as `null`, I checked the main course page, admissions/application
sections, available fee information, and other relevant sections of the official
university website. If the university did not explicitly state an application fee,
I did not assume that the fee was zero. I recorded the field as `null`.

## 2. Conflicting Information

When information such as tuition fees appeared in different places, I checked
whether the figures referred to the same academic year, student category,
campus, or programme. I preferred information directly associated with the
specific course page and the relevant intake. If the difference could not be
resolved confidently, I did not choose a value based on assumption and recorded
the field as `null` or retained the clearly qualified value with its context.

## 3. Application Fee: No Fee vs Not Mentioned

I would only mark an application fee as waived or zero when the university
explicitly states that there is no application fee, the fee is waived, or
applications are free. If the page simply does not mention an application fee,
that does not prove that the fee is zero. In that situation, I would record
`applicationFeeAmount` as `null` and avoid assuming that no fee exists.

# Part 4 — Approach Note

For a dataset of approximately 10,000 pages, I would use a more scalable
pipeline with Requests/session management, BeautifulSoup or Scrapy for
extraction, structured validation, logging, retries, rate limiting, and
checkpointing. I would also use concurrent requests carefully while respecting
robots.txt and website rate limits.

At scale, the first problems would likely be inconsistent page structures,
JavaScript-rendered content, anti-bot protection, broken URLs, rate limits,
duplicate pages, and changes to website layouts.

If an LLM were used to help parse difficult pages, I would not trust its output
directly. Extracted values would be validated against the source text, expected
data types, currency formats, dates, and page context. Important numerical
values such as tuition fees would require evidence from the source page before
being accepted. If supporting evidence could not be found, the value would be
set to `null`.