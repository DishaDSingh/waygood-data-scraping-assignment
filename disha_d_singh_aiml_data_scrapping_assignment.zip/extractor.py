import requests
from bs4 import BeautifulSoup

url = "https://www.uts.edu.au/courses/bachelor-of-creative-production-in-music-and-sound-design-bachelor-of-creative-intelligence-and-innovation"

headers = {
    "User-Agent": "Mozilla/5.0"
}

response = requests.get(url, headers=headers)

soup = BeautifulSoup(response.text, "html.parser")

print("========== H1 ==========")

h1 = soup.find("h1")

if h1:
    print(h1.get_text(strip=True))

with open("page.html", "w", encoding="utf-8") as f:
    f.write(response.text)

print("HTML saved successfully")
print(soup.get_text("\n", strip=True))
with open("page_text.txt", "w", encoding="utf-8") as f:
    f.write(soup.get_text("\n", strip=True))
    requests.get(url)
    import json
import csv

# Load JSON
with open("courses.json", "r", encoding="utf-8") as file:
    courses = json.load(file)

# Get all column names
fieldnames = set()

for course in courses:
    fieldnames.update(course.keys())

fieldnames = list(fieldnames)

# Write CSV
with open("courses.csv", "w", newline="", encoding="utf-8-sig") as file:
    writer = csv.DictWriter(
        file,
        fieldnames=fieldnames,
        extrasaction="ignore"
    )

    writer.writeheader()

    for course in courses:
        writer.writerow(course)

print("courses.csv created successfully.")