import json

with open("university.json", "r", encoding="utf-8") as f:
    data = json.load(f)

print("University JSON is valid")
print("Number of universities:", len(data))