import json
import pandas as pd

# -----------------------------
# 1. Validate courses.json
# -----------------------------

with open("courses.json", "r", encoding="utf-8") as file:
    courses = json.load(file)

assert isinstance(courses, list), \
    "courses.json must contain a list of courses"

assert len(courses) > 0, \
    "courses.json contains no course records"


# -----------------------------
# 2. Validate courses.csv
# -----------------------------

df = pd.read_csv("courses.csv")

assert len(df) > 0, \
    "courses.csv contains no records"


# -----------------------------
# 3. Required columns
# -----------------------------

required_columns = [
    "universityName",
    "courseName",
    "courseURL",
    "courseLevel",
    "duration"
]

for column in required_columns:
    assert column in df.columns, \
        f"Missing column: {column}"


# -----------------------------
# 4. Check university names
# -----------------------------

assert df["universityName"].notna().all(), \
    "Some university names are missing"


# -----------------------------
# 5. Check course names
# -----------------------------

assert df["courseName"].notna().all(), \
    "Some course names are missing"


# -----------------------------
# 6. Check course URLs
# -----------------------------

assert df["courseURL"].notna().all(), \
    "Some course URLs are missing"


# -----------------------------
# 7. Check duplicate URLs
# -----------------------------

duplicate_urls = df["courseURL"].duplicated().sum()

assert duplicate_urls == 0, \
    f"Duplicate course URLs found: {duplicate_urls}"


# -----------------------------
# 8. Check expected record count
# -----------------------------

assert len(df) == 10, \
    f"Expected 10 courses, found {len(df)}"


# -----------------------------
# 9. Final result
# -----------------------------

print("================================")
print("ALL VALIDATION TESTS PASSED")
print("================================")
print(f"Total courses: {len(df)}")
print(f"Total columns: {len(df.columns)}")
print(f"Duplicate URLs: {duplicate_urls}")
print("Required fields are present.")
print("================================")